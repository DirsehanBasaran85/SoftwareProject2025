#pragma once

void runUdpServer(unsigned short port);
void runUdpClient(unsigned short port);
